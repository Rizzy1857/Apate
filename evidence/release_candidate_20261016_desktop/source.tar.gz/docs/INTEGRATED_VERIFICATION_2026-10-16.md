# Integrated desktop verification — October 16, 2026

This is a release-candidate checkpoint, not final integrated-product acceptance.
The October 11 MVP evidence remains historical and unchanged.

Verified against the current working tree:

- Default Python regression suite: 262 passed, 7 explicit skips.
- Explicit local HTTP integration suite: 4 passed, covering stalled headers,
  stalled body, token-limit truncation and incomplete streams. These exercise
  the real inference child process and local HTTP transport. Truncated and
  incomplete responses retain safe failure codes and increment the circuit
  breaker; stalled requests leave no inference transport process running.
- Rust suite: 12 passed, 1 opt-in real-core export test ignored by default.
  The real-core export and native export buttons passed on October 15; they
  were not rerun by this unit-test invocation.
- History validation regression no longer randomly samples an empty category.
- `git diff --check` passed.

The first HTTP test invocation was blocked by sandbox socket permissions before
the code could be exercised. The approved loopback invocation passed. Neither
that permission failure nor the local-model diagnostic approval-review timeout
is counted as a product failure or a passing test.

See DESKTOP_VERIFICATION_2026-10-15.md for native startup/shutdown, startup
cancellation/failure, run resume/fresh, core crash recovery, collection-health
failure/recovery, isolation and raw/redacted export observations.

Still required for final acceptance: finish local-model failure follow-up,
verify an extracted frozen candidate, refresh release-specific image/dependency
and capacity evidence, and reconcile requirements with the delivered scope.
No fine-tuning, hallucination-free inference, production security certification
or completed Mirage Home product is claimed.
